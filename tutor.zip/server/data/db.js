// In-memory mock database. Replace with a real DB in production.
export const db = {
  users: [
    { id: 'admin-1', role: 'admin', name: 'Platform Admin', email: 'admin@tutorconnect.com', phone: '+1234567890', passwordHash: '$2a$10$8L6vuuStb3D1mTq7d7V5ueqG5hM5n9EwM1gkF8S34u3p8w4k2QyC2' /* 'admin123' */, approved: true },
    { id: 'teacher-1', role: 'teacher', name: 'Dr. Sarah Johnson', email: 'sarah@example.com', phone: '+1234567891', passwordHash: '$2a$10$8L6vuuStb3D1mTq7d7V5ueqG5hM5n9EwM1gkF8S34u3p8w4k2QyC2', approved: true },
    { id: 'teacher-2', role: 'teacher', name: 'Prof. Michael Chen', email: 'michael@example.com', phone: '+1234567892', passwordHash: '$2a$10$8L6vuuStb3D1mTq7d7V5ueqG5hM5n9EwM1gkF8S34u3p8w4k2QyC2', approved: true },
    { id: 'teacher-3', role: 'teacher', name: 'Ms. Emily Rodriguez', email: 'emily@example.com', phone: '+1234567893', passwordHash: '$2a$10$8L6vuuStb3D1mTq7d7V5ueqG5hM5n9EwM1gkF8S34u3p8w4k2QyC2', approved: false },
    { id: 'student-1', role: 'student', name: 'Alex Thompson', email: 'alex@example.com', phone: '+1234567894', passwordHash: '$2a$10$8L6vuuStb3D1mTq7d7V5ueqG5hM5n9EwM1gkF8S34u3p8w4k2QyC2', approved: true },
    { id: 'student-2', role: 'student', name: 'Jessica Williams', email: 'jessica@example.com', phone: '+1234567895', passwordHash: '$2a$10$8L6vuuStb3D1mTq7d7V5ueqG5hM5n9EwM1gkF8S34u3p8w4k2QyC2', approved: true },
  ],
  teachers: [
    { id: 'teacher-1', subjects: ['Mathematics', 'Physics'], experience: 8, timings: ['Morning', 'Evening'], rate: 50, mode: 'both', areas: ['Downtown', 'University District'], ratings: { avg: 4.8, count: 24 }, completed: 156, earnings: 7800 },
    { id: 'teacher-2', subjects: ['Computer Science', 'Programming'], experience: 12, timings: ['Afternoon', 'Evening'], rate: 75, mode: 'online', areas: [], ratings: { avg: 4.9, count: 18 }, completed: 89, earnings: 6675 },
    { id: 'teacher-3', subjects: ['English', 'Literature'], experience: 5, timings: ['Morning', 'Afternoon'], rate: 40, mode: 'offline', areas: ['Suburbs', 'City Center'], ratings: { avg: 0, count: 0 }, completed: 0, earnings: 0 },
  ],
  students: [
    { id: 'student-1', subjects: ['Mathematics', 'Physics'], location: 'Downtown', mode: 'both', payments: [] },
    { id: 'student-2', subjects: ['Computer Science'], location: 'University District', mode: 'online', payments: [] },
  ],
  bookings: [
    { id: 'bk-1', studentId: 'student-1', teacherId: 'teacher-1', subject: 'Mathematics', mode: 'online', datetime: '2024-01-15T10:00:00Z', price: 50, status: 'completed' },
    { id: 'bk-2', studentId: 'student-1', teacherId: 'teacher-1', subject: 'Physics', mode: 'offline', datetime: '2024-01-20T14:00:00Z', price: 50, status: 'completed' },
    { id: 'bk-3', studentId: 'student-2', teacherId: 'teacher-2', subject: 'Programming', mode: 'online', datetime: '2024-01-25T16:00:00Z', price: 75, status: 'completed' },
    { id: 'bk-4', studentId: 'student-1', teacherId: 'teacher-2', subject: 'Computer Science', mode: 'online', datetime: '2024-02-01T15:00:00Z', price: 75, status: 'accepted' },
  ],
  payments: [
    { id: 'pm-1', bookingId: 'bk-1', amount: 50, status: 'released', method: 'card' },
    { id: 'pm-2', bookingId: 'bk-2', amount: 50, status: 'released', method: 'card' },
    { id: 'pm-3', bookingId: 'bk-3', amount: 75, status: 'released', method: 'paypal' },
    { id: 'pm-4', bookingId: 'bk-4', amount: 75, status: 'paid', method: 'card' },
  ],
  reviews: [
    { id: 'rv-1', bookingId: 'bk-1', studentId: 'student-1', teacherId: 'teacher-1', rating: 5, comment: 'Excellent teacher! Very clear explanations and patient with questions.', createdAt: '2024-01-15T12:00:00Z' },
    { id: 'rv-2', bookingId: 'bk-2', studentId: 'student-1', teacherId: 'teacher-1', rating: 4, comment: 'Good session, helped me understand complex physics concepts.', createdAt: '2024-01-20T16:00:00Z' },
    { id: 'rv-3', bookingId: 'bk-3', studentId: 'student-2', teacherId: 'teacher-2', rating: 5, comment: 'Amazing programming mentor! Learned so much in one session.', createdAt: '2024-01-25T18:00:00Z' },
  ],
}
