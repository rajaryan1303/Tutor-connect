import { Router } from 'express'
import { db } from '../data/db.js'
import { authRequired } from '../middleware/auth.js'

const router = Router()

// Mock payment: marks booking as paid and reserves amount for teacher
router.post('/pay', authRequired('student'), (req, res) => {
  const { bookingId, method = 'mock' } = req.body
  const b = db.bookings.find(x => x.id === bookingId && x.studentId === req.user.id)
  if (!b) return res.status(404).json({ error: 'Booking not found' })
  const payment = { id: `pm-${Date.now()}`, bookingId, amount: b.price, status: 'paid', method }
  db.payments.push(payment)
  res.json({ payment })
})

router.get('/me', authRequired(), (req, res) => {
  const myBookings = db.bookings.filter(b => (req.user.role === 'student' ? b.studentId === req.user.id : b.teacherId === req.user.id))
  const ids = new Set(myBookings.map(b => b.id))
  const payments = db.payments.filter(p => ids.has(p.bookingId))
  res.json({ payments })
})

export default router
