import { Router } from 'express'
import { db } from '../data/db.js'
import { authRequired } from '../middleware/auth.js'

const router = Router()

router.get('/', authRequired(), (req, res) => {
  let items = db.bookings
  if (req.user.role === 'student') items = items.filter(b => b.studentId === req.user.id)
  if (req.user.role === 'teacher') items = items.filter(b => b.teacherId === req.user.id)
  res.json({ bookings: items })
})

router.post('/', authRequired('student'), (req, res) => {
  const { teacherId, subject, mode, datetime, price } = req.body
  const id = `bk-${Date.now()}`
  const booking = { id, studentId: req.user.id, teacherId, subject, mode, datetime, price, status: 'pending' }
  db.bookings.push(booking)
  res.json({ booking })
})

router.post('/:id/complete', authRequired('teacher'), (req, res) => {
  const b = db.bookings.find(x => x.id === req.params.id && x.teacherId === req.user.id)
  if (!b) return res.status(404).json({ error: 'Not found' })
  b.status = 'completed'
  res.json({ booking: b })
})

export default router
