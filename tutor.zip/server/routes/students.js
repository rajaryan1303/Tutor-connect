import { Router } from 'express'
import { db } from '../data/db.js'
import { authRequired } from '../middleware/auth.js'

const router = Router()

router.get('/me', authRequired('student'), (req, res) => {
  const profile = db.students.find(s => s.id === req.user.id)
  res.json({ profile })
})

router.put('/me', authRequired('student'), (req, res) => {
  const profile = db.students.find(s => s.id === req.user.id)
  Object.assign(profile, req.body)
  res.json({ profile })
})

router.get('/teachers', authRequired('student'), (req, res) => {
  const { subject, location, mode, minRate, maxRate } = req.query
  let list = db.teachers
    .map(t => ({
      ...t,
      ...db.users.find(u => u.id === t.id),
    }))
    .filter(t => db.users.find(u => u.id === t.id)?.approved)
  if (subject) list = list.filter(t => t.subjects.includes(subject))
  if (location) list = list.filter(t => t.areas.includes(location))
  if (mode) list = list.filter(t => t.mode === mode || t.mode === 'both')
  if (minRate) list = list.filter(t => Number(t.rate) >= Number(minRate))
  if (maxRate) list = list.filter(t => Number(t.rate) <= Number(maxRate))
  res.json({ teachers: list })
})

export default router
