import React, { useEffect, useState } from 'react'
import { useAuth } from '../context/AuthContext.jsx'
import { Star, Calendar, Clock, MapPin, Monitor, Users } from 'lucide-react'

export default function StudentDashboard() {
  const { api } = useAuth()
  const [teachers, setTeachers] = useState([])
  const [bookings, setBookings] = useState([])
  const [reviews, setReviews] = useState([])
  const [filters, setFilters] = useState({ subject: '', location: '', mode: '' })
  const [message, setMessage] = useState('')
  const [showReviewModal, setShowReviewModal] = useState(false)
  const [selectedBooking, setSelectedBooking] = useState(null)
  const [reviewForm, setReviewForm] = useState({ rating: 5, comment: '' })

  async function load() {
    try {
      const t = await api(`/students/teachers?subject=${filters.subject}&location=${filters.location}&mode=${filters.mode}`)
      setTeachers(t.teachers)
      const b = await api('/bookings')
      setBookings(b.bookings)
    } catch (e) {
      console.error('Failed to load data:', e)
    }
  }

  useEffect(() => { load() }, [])

  async function book(teacherId) {
    setMessage('')
    const teacher = teachers.find(t => t.id === teacherId)
    const price = teacher?.rate || 50
    const datetime = new Date().toISOString()
    const subject = filters.subject || (teacher?.subjects?.[0] || 'General')
    const mode = filters.mode || 'online'
    try {
      const { booking } = await api('/bookings', 'POST', { teacherId, subject, mode, datetime, price })
      await api('/payments/pay', 'POST', { bookingId: booking.id })
      setMessage('Booked and paid successfully! Awaiting teacher acceptance.')
      await load()
    } catch (e) {
      setMessage('Booking failed: ' + e.message)
    }
  }

  async function submitReview() {
    try {
      await api('/reviews', 'POST', {
        bookingId: selectedBooking.id,
        rating: reviewForm.rating,
        comment: reviewForm.comment
      })
      setShowReviewModal(false)
      setReviewForm({ rating: 5, comment: '' })
      setMessage('Review submitted successfully!')
      await load()
    } catch (e) {
      setMessage('Failed to submit review: ' + e.message)
    }
  }

  function openReviewModal(booking) {
    setSelectedBooking(booking)
    setShowReviewModal(true)
  }

  function renderStars(rating) {
    return Array.from({ length: 5 }, (_, i) => (
      <Star key={i} size={16} className={i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'} />
    ))
  }

  const completedBookings = bookings.filter(b => b.status === 'completed')
  const activeBookings = bookings.filter(b => b.status !== 'completed')

  return (
    <div className="container">
      <h1 className="page-title">Student Dashboard</h1>
      
      {/* Search Teachers */}
      <div className="card p-6 mb-8">
        <h2 className="text-xl font-semibold mb-4 dark:text-dark-heading">Find Teachers</h2>
        <div className="grid md:grid-cols-4 gap-4">
          <input placeholder="Subject" className="input" value={filters.subject} onChange={e=>setFilters({...filters, subject:e.target.value})} />
          <input placeholder="Location" className="input" value={filters.location} onChange={e=>setFilters({...filters, location:e.target.value})} />
          <select className="input" value={filters.mode} onChange={e=>setFilters({...filters, mode:e.target.value})}>
            <option value="">Any Mode</option>
            <option value="online">Online</option>
            <option value="offline">Offline</option>
            <option value="both">Both</option>
          </select>
          <button className="btn" onClick={load}>Search</button>
        </div>
      </div>

      {message && (
        <div className={`card p-4 mb-6 ${message.includes('success') ? 'bg-green-50 text-green-700 border-green-200' : message.includes('failed') || message.includes('Failed') ? 'bg-red-50 text-red-700 border-red-200' : 'bg-blue-50 text-blue-700 border-blue-200'}`}>
          {message}
        </div>
      )}

      {/* Available Teachers */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4 dark:text-dark-heading">Available Teachers</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {teachers.map(t => (
            <div key={t.id} className="card p-6 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="font-semibold text-lg dark:text-dark-heading">{t.name}</h3>
                  <div className="flex items-center gap-1 mt-1">
                    {renderStars(Math.round(t.ratings?.avg || 0))}
                    <span className="text-sm text-slate-600 dark:text-slate-400 ml-1">
                      {t.ratings?.avg?.toFixed(1) || 'No ratings'} ({t.ratings?.count || 0})
                    </span>
                  </div>
                </div>
                <span className="text-lg font-bold text-primary-600 dark:text-primary-400">${t.rate}/hr</span>
              </div>
              
              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                  <Users size={16} />
                  <span>{t.subjects?.join(', ') || 'N/A'}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                  <Calendar size={16} />
                  <span>{t.experience} years experience</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                  {t.mode === 'online' ? <Monitor size={16} /> : t.mode === 'offline' ? <MapPin size={16} /> : <><Monitor size={16} /><MapPin size={16} /></>}
                  <span>{t.mode === 'both' ? 'Online & Offline' : t.mode}</span>
                </div>
              </div>
              
              <button className="btn w-full" onClick={() => book(t.id)}>
                Book Session
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Active Bookings */}
      {activeBookings.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4 dark:text-dark-heading">Active Bookings</h2>
          <div className="grid gap-4">
            {activeBookings.map(b => (
              <div key={b.id} className="card p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-semibold dark:text-dark-heading">{b.subject}</h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400">Teacher: {b.teacherId}</p>
                    <div className="flex items-center gap-4 mt-2 text-sm text-slate-600 dark:text-slate-400">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        b.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        b.status === 'accepted' ? 'bg-green-100 text-green-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {b.status}
                      </span>
                      <span>${b.price}</span>
                      <span>{b.mode}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Completed Sessions */}
      {completedBookings.length > 0 && (
        <div>
          <h2 className="text-xl font-semibold mb-4 dark:text-dark-heading">Completed Sessions</h2>
          <div className="grid gap-4">
            {completedBookings.map(b => {
              const hasReview = reviews.some(r => r.bookingId === b.id)
              return (
                <div key={b.id} className="card p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold dark:text-dark-heading">{b.subject}</h3>
                      <p className="text-sm text-slate-600 dark:text-slate-400">Teacher: {b.teacherId}</p>
                      <div className="flex items-center gap-4 mt-2 text-sm text-slate-600 dark:text-slate-400">
                        <span className="px-2 py-1 rounded text-xs font-medium bg-green-100 text-green-800">
                          Completed
                        </span>
                        <span>${b.price}</span>
                        <span>{b.mode}</span>
                      </div>
                    </div>
                    {!hasReview && (
                      <button 
                        className="btn btn-secondary text-sm"
                        onClick={() => openReviewModal(b)}
                      >
                        Leave Review
                      </button>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* Review Modal */}
      {showReviewModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="card p-6 max-w-md w-full mx-4">
            <h3 className="text-lg font-semibold mb-4 dark:text-dark-heading">Leave a Review</h3>
            <div className="mb-4">
              <label className="label mb-2">Rating</label>
              <div className="flex gap-1">
                {Array.from({ length: 5 }, (_, i) => (
                  <button
                    key={i}
                    onClick={() => setReviewForm({...reviewForm, rating: i + 1})}
                    className="p-1"
                  >
                    <Star 
                      size={24} 
                      className={i < reviewForm.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'} 
                    />
                  </button>
                ))}
              </div>
            </div>
            <div className="mb-4">
              <label className="label mb-2">Comment</label>
              <textarea
                className="input"
                rows={4}
                value={reviewForm.comment}
                onChange={e => setReviewForm({...reviewForm, comment: e.target.value})}
                placeholder="Share your experience..."
              />
            </div>
            <div className="flex gap-3">
              <button className="btn flex-1" onClick={submitReview}>
                Submit Review
              </button>
              <button 
                className="btn btn-secondary flex-1" 
                onClick={() => setShowReviewModal(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
