import { Router } from 'express'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { db } from '../data/db.js'

const router = Router()

function sign(user) {
  return jwt.sign({ id: user.id, role: user.role, name: user.name, email: user.email }, process.env.JWT_SECRET, { expiresIn: '7d' })
}

router.post('/register', async (req, res) => {
  try {
    const { role, name, email, phone, password } = req.body
    if (!['student', 'teacher'].includes(role)) return res.status(400).json({ error: 'Invalid role' })
    if (db.users.some(u => u.email === email)) return res.status(400).json({ error: 'Email already used' })
    const passwordHash = await bcrypt.hash(password, 10)
    const id = `${role}-${Date.now()}`
    const base = { id, role, name, email, phone, passwordHash, approved: role === 'teacher' ? false : true }
    db.users.push(base)
    if (role === 'student') {
      db.students.push({ id, subjects: [], location: '', mode: 'online', payments: [] })
    } else if (role === 'teacher') {
      db.teachers.push({ id, subjects: [], experience: 0, timings: [], rate: 0, mode: 'online', areas: [], ratings: { avg: 0, count: 0 }, completed: 0, earnings: 0 })
    }
    return res.json({ token: sign(base), user: { id: base.id, role: base.role, name: base.name, email: base.email, approved: base.approved } })
  } catch (e) {
    res.status(500).json({ error: 'Registration failed' })
  }
})

router.post('/login', async (req, res) => {
  const { email, password } = req.body
  const user = db.users.find(u => u.email === email)
  if (!user) return res.status(400).json({ error: 'Invalid credentials' })
  const ok = await bcrypt.compare(password, user.passwordHash)
  if (!ok) return res.status(400).json({ error: 'Invalid credentials' })
  return res.json({ token: sign(user), user: { id: user.id, role: user.role, name: user.name, email: user.email, approved: user.approved } })
})

export default router
