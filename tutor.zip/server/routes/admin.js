import { Router } from 'express'
import { db } from '../data/db.js'
import { authRequired } from '../middleware/auth.js'

const router = Router()

router.get('/users', authRequired('admin'), (req, res) => {
  res.json({ users: db.users })
})

router.post('/teachers/:id/approve', authRequired('admin'), (req, res) => {
  const user = db.users.find(u => u.id === req.params.id && u.role === 'teacher')
  if (!user) return res.status(404).json({ error: 'Not found' })
  user.approved = true
  res.json({ user })
})

router.get('/analytics', authRequired('admin'), (req, res) => {
  const revenue = db.payments.reduce((s, p) => s + Number(p.amount || 0), 0)
  const activeStudents = new Set(db.bookings.map(b => b.studentId)).size
  const activeTeachers = new Set(db.bookings.map(b => b.teacherId)).size
  res.json({
    totals: {
      users: db.users.length,
      students: db.users.filter(u => u.role === 'student').length,
      teachers: db.users.filter(u => u.role === 'teacher').length,
      bookings: db.bookings.length,
      revenue,
      activeStudents,
      activeTeachers,
    }
  })
})

// Release teacher payment (mock). In real world, integrate payout APIs.
router.post('/payouts/release', authRequired('admin'), (req, res) => {
  const { bookingId } = req.body
  const b = db.bookings.find(x => x.id === bookingId)
  if (!b) return res.status(404).json({ error: 'Booking not found' })
  const p = db.payments.find(x => x.bookingId === bookingId)
  if (!p || p.status !== 'paid') return res.status(400).json({ error: 'No paid amount to release' })
  p.status = 'released'
  const t = db.teachers.find(t => t.id === b.teacherId)
  if (t) t.earnings += Number(p.amount || 0)
  res.json({ payment: p })
})

export default router
