import { Router } from 'express'
import { db } from '../data/db.js'
import { authRequired } from '../middleware/auth.js'

const router = Router()

router.get('/me', authRequired('teacher'), (req, res) => {
  const profile = db.teachers.find(t => t.id === req.user.id)
  res.json({ profile })
})

router.put('/me', authRequired('teacher'), (req, res) => {
  const profile = db.teachers.find(t => t.id === req.user.id)
  Object.assign(profile, req.body)
  res.json({ profile })
})

router.get('/bookings', authRequired('teacher'), (req, res) => {
  const items = db.bookings.filter(b => b.teacherId === req.user.id)
  res.json({ bookings: items })
})

router.post('/bookings/:id/accept', authRequired('teacher'), (req, res) => {
  const b = db.bookings.find(x => x.id === req.params.id && x.teacherId === req.user.id)
  if (!b) return res.status(404).json({ error: 'Not found' })
  b.status = 'accepted'
  res.json({ booking: b })
})

router.post('/bookings/:id/reject', authRequired('teacher'), (req, res) => {
  const b = db.bookings.find(x => x.id === req.params.id && x.teacherId === req.user.id)
  if (!b) return res.status(404).json({ error: 'Not found' })
  b.status = 'rejected'
  res.json({ booking: b })
})

export default router
