import { Router } from 'express'
import { db } from '../data/db.js'
import { authRequired } from '../middleware/auth.js'

const router = Router()

router.post('/', authRequired('student'), (req, res) => {
  const { bookingId, rating, comment } = req.body
  const b = db.bookings.find(x => x.id === bookingId && x.studentId === req.user.id && x.status === 'completed')
  if (!b) return res.status(400).json({ error: 'Invalid booking to review' })
  const id = `rv-${Date.now()}`
  const review = { id, bookingId, studentId: req.user.id, teacherId: b.teacherId, rating: Number(rating), comment }
  db.reviews.push(review)
  // Update teacher rating
  const list = db.reviews.filter(r => r.teacherId === b.teacherId)
  const avg = list.reduce((s, r) => s + r.rating, 0) / list.length
  const t = db.teachers.find(t => t.id === b.teacherId)
  if (t) t.ratings = { avg: Number(avg.toFixed(2)), count: list.length }
  res.json({ review })
})

router.get('/teacher/:id', (req, res) => {
  const items = db.reviews.filter(r => r.teacherId === req.params.id)
  res.json({ reviews: items })
})

export default router
